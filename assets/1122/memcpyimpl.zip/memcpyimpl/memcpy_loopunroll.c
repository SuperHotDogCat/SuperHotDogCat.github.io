#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include "timeutils.h"

void *memcpy_loopunroll(void* dst, const void* src, size_t n){
    const char* s = (const char*) src;
    char* d = (char*) dst;

    while (n >= 128){
        *(int64_t*)d = *(const int64_t*)s;
        *(int64_t*)(d + 8) = *(const int64_t*)(s + 8);
        *(int64_t*)(d + 16) = *(const int64_t*)(s + 16);
        *(int64_t*)(d + 24) = *(const int64_t*)(s + 24);
        *(int64_t*)(d + 32) = *(const int64_t*)(s + 32);
        *(int64_t*)(d + 40) = *(const int64_t*)(s + 40);
        *(int64_t*)(d + 48) = *(const int64_t*)(s + 48);
        *(int64_t*)(d + 56) = *(const int64_t*)(s + 56);
        *(int64_t*)(d + 64) = *(const int64_t*)(s + 64);
        *(int64_t*)(d + 72) = *(const int64_t*)(s + 72);
        *(int64_t*)(d + 80) = *(const int64_t*)(s + 80);
        *(int64_t*)(d + 88) = *(const int64_t*)(s + 88);
        *(int64_t*)(d + 96) = *(const int64_t*)(s + 96);
        *(int64_t*)(d + 104) = *(const int64_t*)(s + 104);
        *(int64_t*)(d + 112) = *(const int64_t*)(s + 112);
        *(int64_t*)(d + 120) = *(const int64_t*)(s + 120);

        d += 128;
        s += 128;
        n -= 128;
    }
    while (n >= 8){
        *(int64_t*)d = *(const int64_t*)s;
        n -= 8;
        d += 8;
        s += 8;
    }
    while (n--){
        *(d++) = *(s++);
    }
    return dst;
}

int main(){
    long long N = 1 << 30; // 1G elements
    long long iter = 10;
    char* src = (char*)malloc(sizeof(char) * N);
    char* dst = (char*)malloc(sizeof(char) * N);
    memset((void *)src, 1, N);
    memset((void *)dst, 0, N); // init and alloc physical memory

    Time* start = timeEvent();
    for (long long i = 0; i < iter; ++i) memcpy_loopunroll((void *)dst, (void *)src, N);
    Time* end = timeEvent();
    // checksum
    assert(sum(dst, N) == N);
    double elapsed = elapsedTime(start, end) / iter;
    printf("Elapsed: %lf\n", elapsed);
    printf("Achieved Bandwidth %lf GB/s\n", 2 * N / elapsed / 1e9);
}
