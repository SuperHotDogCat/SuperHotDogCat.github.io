#ifndef UTIL_H_
#define UTIL_H_

#include <stdlib.h>
#include <time.h>

typedef struct timespec Time;
Time* timeEvent(){
    Time* t = (Time*)malloc(1 * sizeof(Time));
    clock_gettime(CLOCK_MONOTONIC, t);
    return t;
}

double elapsedTime(Time* start, Time* end){
    return (double)(end->tv_sec - start->tv_sec) + (double)(end->tv_nsec - start->tv_nsec) / 1e9;
}

long long sum(char* a, long long N){
    long long s = 0;
    for (long long i = 0; i < N; ++i){
        s += a[i];
    }
    return s;
}

#endif
