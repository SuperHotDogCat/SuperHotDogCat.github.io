#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include "timeutils.h"

void *memcpy_8byte(void* dst, const void* src, size_t n){
    const char* s = (const char*) src;
    char* d = (char*) dst;

    while (n >= 8){
        *(int64_t*)d = *(const int64_t*)s;
        n -= 8;
        d += 8;
        s += 8;
    }
    while (n--){
        *(d++) = *(s++);
    }
    return dst;
}

int main(){
    long long N = 1 << 30; // 1G elements
    long long iter = 10;
    char* src = (char*)malloc(sizeof(char) * N);
    char* dst = (char*)malloc(sizeof(char) * N);
    memset((void *)src, 1, N);
    memset((void *)dst, 0, N); // init and alloc physical memory

    Time* start = timeEvent();
    for (long long i = 0; i < iter; ++i) memcpy_8byte((void *)dst, (void *)src, N);
    Time* end = timeEvent();
    // checksum
    assert(sum(dst, N) == N);
    double elapsed = elapsedTime(start, end) / iter;
    printf("Elapsed: %lf\n", elapsed);
    printf("Achieved Bandwidth %lf GB/s\n", 2 * N / elapsed / 1e9);
}
