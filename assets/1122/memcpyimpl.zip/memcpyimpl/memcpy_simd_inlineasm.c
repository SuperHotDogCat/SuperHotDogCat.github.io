#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>
#include <assert.h>
#include "timeutils.h"

void *memcpy_simd_inline(void* dst, const void* src, size_t n){
    const uint8_t* s = (const uint8_t*) src;
    uint8_t* d = (uint8_t*) dst;

    while (n >= 128) {
        __asm__ volatile (
            "ldp q0, q1, [%[s]]\n\t"
            "ldp q2, q3, [%[s], #32]\n\t"
            "ldp q4, q5, [%[s], #64]\n\t"
            "ldp q6, q7, [%[s], #96]\n\t"
            "stp q0, q1, [%[d]]\n\t"
            "stp q2, q3, [%[d], #32]\n\t"
            "stp q4, q5, [%[d], #64]\n\t"
            "stp q6, q7, [%[d], #96]\n\t"
            :
            : [s] "r" (s), [d] "r" (d)
            : "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7", "memory"
        );

        s += 128;
        d += 128;
        n -= 128;
    }
    while (n >= 8){
        *(int64_t*)d = *(const int64_t*)s;
        n -= 8;
        d += 8;
        s += 8;
    }
    while (n--){
        *(d++) = *(s++);
    }
    return dst;
}

int main(){
    long long N = 1 << 30; // 1G elements
    long long iter = 10;
    char* src = (char*)malloc(sizeof(char) * N);
    char* dst = (char*)malloc(sizeof(char) * N);
    memset((void *)src, 1, N);
    memset((void *)dst, 0, N); // init and alloc physical memory

    Time* start = timeEvent();
    for (long long i = 0; i < iter; ++i) memcpy_simd_inline((void *)dst, (void *)src, N);
    Time* end = timeEvent();
    // checksum
    assert(sum(dst, N) == N);
    double elapsed = elapsedTime(start, end) / iter;
    printf("Elapsed: %lf\n", elapsed);
    printf("Achieved Bandwidth %lf GB/s\n", 2 * N / elapsed / 1e9);
}
