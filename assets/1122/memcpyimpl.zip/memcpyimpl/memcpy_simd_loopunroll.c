#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>
#include <assert.h>
#include "timeutils.h"

void *memcpy_simd_unroll(void* restrict dst, const void* restrict src, size_t n){
    const uint8_t* s = (const uint8_t*) src;
    uint8_t* d = (uint8_t*) dst;

    while (n >= 128) {
        uint8x16_t v0 = vld1q_u8(s);
        uint8x16_t v1 = vld1q_u8(s + 16);
        uint8x16_t v2 = vld1q_u8(s + 32);
        uint8x16_t v3 = vld1q_u8(s + 48);
        uint8x16_t v4 = vld1q_u8(s + 64);
        uint8x16_t v5 = vld1q_u8(s + 80);
        uint8x16_t v6 = vld1q_u8(s + 96);
        uint8x16_t v7 = vld1q_u8(s + 112);


        vst1q_u8(d, v0);
        vst1q_u8(d + 16, v1);
        vst1q_u8(d + 32, v2);
        vst1q_u8(d + 48, v3);
        vst1q_u8(d + 64, v4);
        vst1q_u8(d + 80, v5);
        vst1q_u8(d + 96, v6);
        vst1q_u8(d + 112, v7);

        s += 128;
        d += 128;
        n -= 128;
    }
    while (n >= 8){
        *(int64_t*)d = *(const int64_t*)s;
        n -= 8;
        d += 8;
        s += 8;
    }
    while (n--){
        *(d++) = *(s++);
    }
    return dst;
}

int main(){
    long long N = 1 << 30; // 1G elements
    long long iter = 10;
    char* src = (char*)malloc(sizeof(char) * N);
    char* dst = (char*)malloc(sizeof(char) * N);
    memset((void *)src, 1, N);
    memset((void *)dst, 0, N); // init and alloc physical memory

    Time* start = timeEvent();
    for (long long i = 0; i < iter; ++i) memcpy_simd_unroll((void *)dst, (void *)src, N);
    Time* end = timeEvent();
    // checksum
    assert(sum(dst, N) == N);
    double elapsed = elapsedTime(start, end) / iter;
    printf("Elapsed: %lf\n", elapsed);
    printf("Achieved Bandwidth %lf GB/s\n", 2 * N / elapsed / 1e9);
}
