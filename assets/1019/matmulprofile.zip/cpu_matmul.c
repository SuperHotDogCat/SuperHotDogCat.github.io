// Naive FP32 matmul (C = A * B, square N x N, row-major).
// The plain triple loop everyone writes first: single thread, no blocking,
// no explicit SIMD.
//
// Usage: ./cpu_matmul [-o out.csv] [-m max_n] [-n min_n] [--check]
// Sweeps N upward and stops a little after performance saturates.
// The naive loop saturates almost immediately, so it never stops before min_n
// (default 1024) in order to show the drop once the matrices leave cache.

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Saturation rule: stop after PATIENCE consecutive sizes that fail to beat
// the best GFLOPS so far by IMPROVE_RATIO.
#define IMPROVE_RATIO 1.03
#define PATIENCE 3

static void matmul(int n, const float *A, const float *B, float *C) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            float sum = 0.0f;
            for (int k = 0; k < n; k++) sum += A[i * n + k] * B[k * n + j];
            C[i * n + j] = sum;
        }
}

static double now(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static float *alloc_random(int n) {
    float *x = malloc((size_t)n * n * sizeof(float));
    if (!x) { perror("malloc"); exit(1); }
    for (size_t i = 0; i < (size_t)n * n; i++) x[i] = (float)rand() / RAND_MAX - 0.5f;
    return x;
}

static int check(int n) {
    float *A = alloc_random(n), *B = alloc_random(n), *C = alloc_random(n);
    matmul(n, A, B, C);
    double maxerr = 0.0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            double ref = 0.0;
            for (int k = 0; k < n; k++) ref += (double)A[i * n + k] * B[k * n + j];
            double e = fabs(ref - C[i * n + j]);
            if (e > maxerr) maxerr = e;
        }
    printf("check N=%d max abs err = %.3e\n", n, maxerr);
    free(A); free(B); free(C);
    return maxerr < 1e-3 * n ? 0 : 1;
}

// Best time per call. Repeats until >= 1 s total (at least 3 runs for
// small sizes; a single run is enough once one call takes >= 1 s).
static double bench(int n) {
    float *A = alloc_random(n), *B = alloc_random(n), *C = alloc_random(n);
    double best = 1e30, total = 0.0;
    int reps = 0;
    while (total < 1.0 || (reps < 3 && best < 0.1)) {
        double t0 = now();
        matmul(n, A, B, C);
        double t = now() - t0;
        if (t < best) best = t;
        total += t;
        reps++;
    }
    free(A); free(B); free(C);
    return best;
}

int main(int argc, char **argv) {
    const char *out = "result_cpu_naive.csv";
    int max_n = 8192, min_n = 1024;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-o") && i + 1 < argc) out = argv[++i];
        else if (!strcmp(argv[i], "-m") && i + 1 < argc) max_n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-n") && i + 1 < argc) min_n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--check")) return check(127) | check(256);
    }

    FILE *fp = fopen(out, "w");
    if (!fp) { perror(out); return 1; }
    fprintf(fp, "impl,n,time_s,gflops\n");

    double best_gf = 0.0;
    int stale = 0;
    // Sizes: 64, 96, 128, 192, 256, 384, ... (2^k and 1.5 * 2^k)
    for (int base = 64; base <= max_n; base *= 2) {
        int sizes[2] = {base, base + base / 2};
        for (int s = 0; s < 2; s++) {
            int n = sizes[s];
            if (n > max_n) break;
            double t = bench(n);
            double gf = 2.0 * n * (double)n * n / t * 1e-9;
            printf("[cpu_naive] N=%6d  time=%.6f s  %.2f GFLOPS\n", n, t, gf);
            fflush(stdout);
            fprintf(fp, "cpu_naive,%d,%.9e,%.6f\n", n, t, gf);
            fflush(fp);
            if (gf > best_gf * IMPROVE_RATIO) { best_gf = gf; stale = 0; }
            else { if (gf > best_gf) best_gf = gf; stale++; }
            if (stale >= PATIENCE && n >= min_n) { fclose(fp); printf("[cpu_naive] saturated\n"); return 0; }
        }
    }
    fclose(fp);
    return 0;
}
