"""Shared size sweep for the numpy / torch benchmarks.

Sizes go 64, 96, 128, 192, 256, ... and the sweep stops after PATIENCE
consecutive sizes that fail to beat the best GFLOPS so far by IMPROVE_RATIO,
i.e. a little past the point where performance saturates.
"""
import csv

IMPROVE_RATIO = 1.03
PATIENCE = 3


def sizes(start=64, max_n=65536):
    base = start
    while base <= max_n:
        for n in (base, base + base // 2):
            if n <= max_n:
                yield n
        base *= 2


def sweep(impl, bench_fn, out_csv, max_n):
    """bench_fn(n) -> time per matmul call [s]"""
    best_gf, stale = 0.0, 0
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["impl", "n", "time_s", "gflops"])
        for n in sizes(max_n=max_n):
            t = bench_fn(n)
            gf = 2.0 * n**3 / t * 1e-9
            print(f"[{impl}] N={n:6d}  time={t:.6f} s  {gf:.1f} GFLOPS", flush=True)
            w.writerow([impl, n, f"{t:.9e}", f"{gf:.6f}"])
            f.flush()
            if gf > best_gf * IMPROVE_RATIO:
                best_gf, stale = gf, 0
            else:
                best_gf = max(best_gf, gf)
                stale += 1
                if stale >= PATIENCE:
                    print(f"[{impl}] saturated", flush=True)
                    break
