"""Benchmark FP32 matmul on CUDA with PyTorch (cuBLAS).

  python bench_torch.py           # strict FP32 (TF32 disabled, CUDA cores)
  python bench_torch.py --tf32    # FP32 inputs, TF32 Tensor Cores allowed
"""
import argparse

import torch

from sweep import sweep


def make_bench(device):
    def bench(n):
        a = torch.rand(n, n, dtype=torch.float32, device=device)
        b = torch.rand(n, n, dtype=torch.float32, device=device)
        c = torch.empty(n, n, dtype=torch.float32, device=device)
        for _ in range(3):  # warmup (cuBLAS heuristic selection, etc.)
            torch.matmul(a, b, out=c)
        torch.cuda.synchronize()

        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        # Estimate one call, then pick iters so each measurement takes ~50 ms
        start.record()
        torch.matmul(a, b, out=c)
        end.record()
        torch.cuda.synchronize()
        iters = max(1, min(1000, int(50.0 / max(start.elapsed_time(end), 1e-3))))

        best = float("inf")
        for _ in range(5):
            start.record()
            for _ in range(iters):
                torch.matmul(a, b, out=c)
            end.record()
            torch.cuda.synchronize()
            best = min(best, start.elapsed_time(end) / 1e3 / iters)
        del a, b, c
        torch.cuda.empty_cache()
        return best

    return bench


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--tf32", action="store_true")
    p.add_argument("-o", default=None)
    p.add_argument("-m", "--max-n", type=int, default=65536)
    args = p.parse_args()

    torch.backends.cuda.matmul.allow_tf32 = args.tf32
    torch.backends.cudnn.allow_tf32 = args.tf32
    torch.set_float32_matmul_precision("high" if args.tf32 else "highest")

    impl = "cuda_tf32" if args.tf32 else "cuda_fp32"
    out = args.o or f"result_{impl}.csv"
    print(torch.__version__, torch.cuda.get_device_name(0), "allow_tf32 =", args.tf32)
    sweep(impl, make_bench("cuda"), out, args.max_n)
