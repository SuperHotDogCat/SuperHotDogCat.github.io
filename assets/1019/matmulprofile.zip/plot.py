"""Make plots from the result CSVs.

CPU (naive, optimized, numpy) and GPU (PyTorch FP32, TF32) results are plotted separately:

  {cpu,gpu}_flops.png    : x = matrix size N, y = achieved GFLOPS (as in README)
  {cpu,gpu}_roofline.png : roofline (x = arithmetic intensity FLOP/Byte, y = GFLOPS)

Arithmetic intensity uses the ideal traffic of reading A, B once and writing C
once (3 * N^2 * 4 bytes), so AI = 2N^3 / (12 N^2) = N/6 FLOP/Byte (upper bound).

Peak numbers are catalog values for Miyabi-G (GH200: 72-core Grace + H100 96GB).
"""
import argparse
import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

# ---- Hardware peaks (GFLOPS, GB/s) ----
GRACE_CORES = 72
GRACE_GHZ = 3.1
GRACE_FLOP_PER_CYCLE = 32  # 128-bit SVE/NEON x 4 FMA pipes x 4 lanes x 2
PEAK = {
    "cpu_1core": GRACE_GHZ * GRACE_FLOP_PER_CYCLE,          # ~99 GFLOPS
    "cpu": GRACE_CORES * GRACE_GHZ * GRACE_FLOP_PER_CYCLE,  # ~7.1 TFLOPS
    "gpu_fp32": 67_000.0,   # H100 (GH200) FP32 CUDA cores
    "gpu_tf32": 494_000.0,  # H100 (GH200) TF32 Tensor Core (dense)
}
BW = {
    "cpu": 512.0,     # LPDDR5X
    "gpu": 4_000.0,   # HBM3
}

# impl -> (legend label, color, marker, peak key, bandwidth key)
SERIES = {
    "cpu_naive": ("CPU naive triple loop (1 thread)", "#2a78d6", "o", "cpu_1core", "cpu"),
    "cpu_opt":   ("CPU optimized (NEON+OpenMP, 72 threads)", "#e87ba4", "v", "cpu", "cpu"),
    "numpy":     ("CPU numpy (OpenBLAS, 64 threads)",        "#eb6834", "s", "cpu", "cpu"),
    "cuda_fp32": ("GPU PyTorch FP32",            "#1baf7a", "^", "gpu_fp32", "gpu"),
    "cuda_tf32": ("GPU PyTorch TF32",            "#eda100", "D", "gpu_tf32", "gpu"),
}
CEIL_LABEL = {
    "cpu_1core": "Grace 1-core peak FP32",
    "cpu": "Grace 72-core peak FP32",
    "gpu_fp32": "H100 peak FP32",
    "gpu_tf32": "H100 peak TF32 TC",
}
# group -> (series in the group, plot title)
GROUPS = {
    "cpu": (["cpu_naive", "cpu_opt", "numpy"], "CPU (Grace)"),
    "gpu": (["cuda_fp32", "cuda_tf32"], "GPU (H100)"),
}


def fmt(gf):
    return f"{gf / 1000:.1f} TFLOPS" if gf >= 1000 else f"{gf:.1f} GFLOPS"


INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"


def load(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    return [int(r["n"]) for r in rows], [float(r["gflops"]) for r in rows]


def style(ax):
    ax.set_xscale("log", base=2)
    ax.set_yscale("log")
    ax.grid(True, which="major", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(MUTED)
    ax.tick_params(colors=MUTED, labelcolor=INK)


def ceiling(ax, y, label):
    ax.axhline(y, color=MUTED, linestyle="--", linewidth=1)
    ax.annotate(f"{label} ({fmt(y)})", xy=(0.01, y), xycoords=("axes fraction", "data"),
                xytext=(0, 3), textcoords="offset points", fontsize=8, color=MUTED, va="bottom")


def plot_flops(data, title, out):
    fig, ax = plt.subplots(figsize=(8, 5.5))
    used = set()
    for impl, (n, gf) in data.items():
        label, color, marker, peak, _ = SERIES[impl]
        ax.plot(n, gf, color=color, marker=marker, markersize=6, linewidth=2, label=label)
        ax.annotate(fmt(max(gf)), xy=(n[gf.index(max(gf))], max(gf)),
                    xytext=(0, -14), textcoords="offset points", fontsize=8, color=INK, ha="center")
        used.add(peak)
    for p in used:
        ceiling(ax, PEAK[p], CEIL_LABEL[p])
    style(ax)
    ax.set_xlabel("Matrix size N (N x N, FP32)", color=INK)
    ax.set_ylabel("Achieved GFLOPS", color=INK)
    ax.set_title(f"FP32 matmul performance vs. size: {title}", color=INK, loc="left")
    ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0, -0.12), ncol=2)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print("saved", out)


def plot_roofline(data, title, out):
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ais = [ni / 6.0 for n, _ in data.values() for ni in n]
    x_lo, x_hi = min(ais) / 2, max(ais) * 2
    used_peak, used_bw = set(), set()
    for impl, (n, gf) in data.items():
        label, color, marker, peak, bw = SERIES[impl]
        ai = [ni / 6.0 for ni in n]
        ax.plot(ai, gf, color=color, marker=marker, markersize=6, linewidth=2, label=label)
        used_peak.add((peak, bw))
        used_bw.add(bw)
    # Roof: min(peak, BW * AI)
    for peak, bw in used_peak:
        ridge = PEAK[peak] / BW[bw]
        xs = [x_lo, ridge, x_hi]
        ys = [BW[bw] * x_lo, PEAK[peak], PEAK[peak]]
        ax.plot(xs, ys, color=MUTED, linestyle="--", linewidth=1)
        ax.annotate(f"{CEIL_LABEL[peak]} ({fmt(PEAK[peak])})", xy=(x_hi, PEAK[peak]),
                    xytext=(-3, 3), textcoords="offset points", fontsize=8, color=MUTED,
                    ha="right", va="bottom")
    for bw in used_bw:
        name = "LPDDR5X" if bw == "cpu" else "HBM3"
        x = x_lo * 1.5
        ax.annotate(f"{name} {BW[bw]:.0f} GB/s", xy=(x, BW[bw] * x), xytext=(2, 6),
                    textcoords="offset points", fontsize=8, color=MUTED, rotation=0)
    style(ax)
    ax.set_xlim(x_lo, x_hi)
    ax.set_xlabel("Arithmetic intensity [FLOP/Byte]  (= N/6, ideal traffic 3N²·4B)", color=INK)
    ax.set_ylabel("Achieved GFLOPS", color=INK)
    ax.set_title(f"FP32 matmul roofline: {title}", color=INK, loc="left")
    ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0, -0.12), ncol=2)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print("saved", out)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dir", default=os.path.dirname(os.path.abspath(__file__)))
    args = p.parse_args()

    for group, (impls, title) in GROUPS.items():
        data = {}
        for impl in impls:
            path = os.path.join(args.dir, f"result_{impl}.csv")
            if os.path.exists(path):
                data[impl] = load(path)
            else:
                print("skip (not found):", path)
        if not data:
            continue
        plot_flops(data, title, os.path.join(args.dir, f"{group}_flops.png"))
        plot_roofline(data, title, os.path.join(args.dir, f"{group}_roofline.png"))
