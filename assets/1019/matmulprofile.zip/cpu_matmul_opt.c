// Optimized FP32 matmul (C = A * B, square N x N, row-major).
// BLIS-style packing + NEON 8x12 micro-kernel + OpenMP.
// Grace (Neoverse-V2) has 128-bit SVE vectors, i.e. the same width as NEON.
//
// Usage: ./cpu_matmul_opt [-o out.csv] [-m max_n] [--check]
// Sweeps N upward and stops a little after performance saturates.

#include <arm_neon.h>
#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MR 8
#define NR 12
#define KC 256

// Saturation rule: stop after PATIENCE consecutive sizes that fail to beat
// the best GFLOPS so far by IMPROVE_RATIO.
#define IMPROVE_RATIO 1.03
#define PATIENCE 3

static float *alloc_f(size_t n) {
    void *p = NULL;
    if (posix_memalign(&p, 64, n * sizeof(float)) != 0) {
        perror("posix_memalign");
        exit(1);
    }
    return (float *)p;
}

// Pack A[0:M, pc:pc+kc] into panels of MR rows (zero-padded at the edge)
static void pack_A(int M, int kc, const float *A, int lda, float *Ap) {
    int npanel = (M + MR - 1) / MR;
#pragma omp for schedule(static)
    for (int p = 0; p < npanel; p++) {
        float *dst = Ap + (size_t)p * MR * kc;
        int i0 = p * MR;
        for (int k = 0; k < kc; k++)
            for (int i = 0; i < MR; i++)
                dst[k * MR + i] = (i0 + i < M) ? A[(size_t)(i0 + i) * lda + k] : 0.0f;
    }
}

// Pack B[pc:pc+kc, 0:N] into panels of NR columns (zero-padded at the edge)
static void pack_B(int N, int kc, const float *B, int ldb, float *Bp) {
    int npanel = (N + NR - 1) / NR;
#pragma omp for schedule(static)
    for (int p = 0; p < npanel; p++) {
        float *dst = Bp + (size_t)p * NR * kc;
        int j0 = p * NR;
        for (int k = 0; k < kc; k++) {
            const float *src = B + (size_t)k * ldb + j0;
            if (j0 + NR <= N) {
                memcpy(dst + k * NR, src, NR * sizeof(float));
            } else {
                for (int j = 0; j < NR; j++)
                    dst[k * NR + j] = (j0 + j < N) ? src[j] : 0.0f;
            }
        }
    }
}

// C[0:MR, 0:NR] += Ap * Bp   (Ap: kc x MR, Bp: kc x NR)
// 24 accumulators + 2 A regs + 3 B regs = 29 vector registers
static inline void kernel_8x12(int kc, const float *restrict Ap, const float *restrict Bp,
                               float *restrict C, int ldc, int mr, int nr) {
    float32x4_t c[MR][3];
#pragma GCC unroll 8
    for (int i = 0; i < MR; i++)
#pragma GCC unroll 3
        for (int j = 0; j < 3; j++) c[i][j] = vdupq_n_f32(0.0f);

    for (int k = 0; k < kc; k++) {
        float32x4_t a0 = vld1q_f32(Ap);
        float32x4_t a1 = vld1q_f32(Ap + 4);
        float32x4_t b0 = vld1q_f32(Bp);
        float32x4_t b1 = vld1q_f32(Bp + 4);
        float32x4_t b2 = vld1q_f32(Bp + 8);
#define ROW(i, a, l)                              \
    c[i][0] = vfmaq_laneq_f32(c[i][0], b0, a, l); \
    c[i][1] = vfmaq_laneq_f32(c[i][1], b1, a, l); \
    c[i][2] = vfmaq_laneq_f32(c[i][2], b2, a, l);
        ROW(0, a0, 0) ROW(1, a0, 1) ROW(2, a0, 2) ROW(3, a0, 3)
        ROW(4, a1, 0) ROW(5, a1, 1) ROW(6, a1, 2) ROW(7, a1, 3)
#undef ROW
        Ap += MR;
        Bp += NR;
    }

    if (mr == MR && nr == NR) {
#pragma GCC unroll 8
        for (int i = 0; i < MR; i++) {
            float *row = C + (size_t)i * ldc;
#pragma GCC unroll 3
            for (int j = 0; j < 3; j++)
                vst1q_f32(row + 4 * j, vaddq_f32(vld1q_f32(row + 4 * j), c[i][j]));
        }
    } else {
        float tmp[MR][NR];
        for (int i = 0; i < MR; i++)
            for (int j = 0; j < 3; j++) vst1q_f32(&tmp[i][4 * j], c[i][j]);
        for (int i = 0; i < mr; i++)
            for (int j = 0; j < nr; j++) C[(size_t)i * ldc + j] += tmp[i][j];
    }
}

// Ap, Bp are allocated by the caller (ceil(N/MR)*MR*KC and ceil(N/NR)*NR*KC floats)
static void sgemm(int N, const float *A, const float *B, float *C, float *Ap, float *Bp) {
    int M = N, K = N;
    int mpanel = (M + MR - 1) / MR;
    int npanel = (N + NR - 1) / NR;
    memset(C, 0, (size_t)M * N * sizeof(float));

#pragma omp parallel
    for (int pc = 0; pc < K; pc += KC) {
        int kc = (K - pc < KC) ? K - pc : KC;
        pack_A(M, kc, A + pc, K, Ap);
        pack_B(N, kc, B + (size_t)pc * N, N, Bp);  // implicit barrier of omp for
#pragma omp for collapse(2) schedule(static)
        for (int jp = 0; jp < npanel; jp++) {
            for (int ip = 0; ip < mpanel; ip++) {
                int i0 = ip * MR, j0 = jp * NR;
                int mr = (M - i0 < MR) ? M - i0 : MR;
                int nr = (N - j0 < NR) ? N - j0 : NR;
                kernel_8x12(kc, Ap + (size_t)ip * MR * kc, Bp + (size_t)jp * NR * kc,
                            C + (size_t)i0 * N + j0, N, mr, nr);
            }
        }
    }
}

static void fill_random(float *x, size_t n) {
    for (size_t i = 0; i < n; i++) x[i] = (float)rand() / RAND_MAX - 0.5f;
}

static int check(int N) {
    float *A = alloc_f((size_t)N * N), *B = alloc_f((size_t)N * N);
    float *C = alloc_f((size_t)N * N);
    float *Ap = alloc_f((size_t)((N + MR - 1) / MR) * MR * KC);
    float *Bp = alloc_f((size_t)((N + NR - 1) / NR) * NR * KC);
    fill_random(A, (size_t)N * N);
    fill_random(B, (size_t)N * N);
    sgemm(N, A, B, C, Ap, Bp);
    double maxerr = 0.0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            double ref = 0.0;
            for (int k = 0; k < N; k++) ref += (double)A[(size_t)i * N + k] * B[(size_t)k * N + j];
            double e = fabs(ref - C[(size_t)i * N + j]);
            if (e > maxerr) maxerr = e;
        }
    printf("check N=%d max abs err = %.3e\n", N, maxerr);
    free(A); free(B); free(C); free(Ap); free(Bp);
    return maxerr < 1e-3 * N ? 0 : 1;
}

// Best time per call; repeats until >= 1 s total (at least 3 runs)
static double bench(int N) {
    float *A = alloc_f((size_t)N * N), *B = alloc_f((size_t)N * N);
    float *C = alloc_f((size_t)N * N);
    float *Ap = alloc_f((size_t)((N + MR - 1) / MR) * MR * KC);
    float *Bp = alloc_f((size_t)((N + NR - 1) / NR) * NR * KC);
    fill_random(A, (size_t)N * N);
    fill_random(B, (size_t)N * N);

    sgemm(N, A, B, C, Ap, Bp);  // warmup
    double best = 1e30, total = 0.0;
    int reps = 0;
    while (reps < 3 || (total < 1.0 && reps < 1000)) {
        double t0 = omp_get_wtime();
        sgemm(N, A, B, C, Ap, Bp);
        double t = omp_get_wtime() - t0;
        if (t < best) best = t;
        total += t;
        reps++;
    }
    free(A); free(B); free(C); free(Ap); free(Bp);
    return best;
}

int main(int argc, char **argv) {
    const char *out = "result_cpu_opt.csv";
    int max_n = 32768;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-o") && i + 1 < argc) out = argv[++i];
        else if (!strcmp(argv[i], "-m") && i + 1 < argc) max_n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--check")) return check(127) | check(512) | check(1000);
    }

    FILE *fp = fopen(out, "w");
    if (!fp) { perror(out); return 1; }
    fprintf(fp, "impl,n,time_s,gflops\n");
    printf("threads = %d\n", omp_get_max_threads());

    double best_gf = 0.0;
    int stale = 0;
    // Sizes: 64, 96, 128, 192, 256, 384, ... (2^k and 1.5 * 2^k)
    for (int base = 64; base <= max_n; base *= 2) {
        int sizes[2] = {base, base + base / 2};
        for (int s = 0; s < 2; s++) {
            int n = sizes[s];
            if (n > max_n) break;
            double t = bench(n);
            double gf = 2.0 * n * (double)n * n / t * 1e-9;
            printf("[cpu_opt] N=%6d  time=%.6f s  %.1f GFLOPS\n", n, t, gf);
            fflush(stdout);
            fprintf(fp, "cpu_opt,%d,%.9e,%.6f\n", n, t, gf);
            fflush(fp);
            if (gf > best_gf * IMPROVE_RATIO) { best_gf = gf; stale = 0; }
            else { if (gf > best_gf) best_gf = gf; stale++; }
            if (stale >= PATIENCE) { fclose(fp); printf("[cpu_opt] saturated\n"); return 0; }
        }
    }
    fclose(fp);
    return 0;
}
