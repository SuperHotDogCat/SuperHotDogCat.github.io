#!/usr/bin/env bash
# Run all FP32 matmul benchmarks and make the plots.
# Meant to be run inside the PyTorch container on a GPU node:
#   bash run_all.sh
#
# Env vars:
#   SKIP  space-separated steps to skip, e.g. SKIP="naive opt numpy"

set -euo pipefail

cd "$(dirname "$(readlink -f "$0")")"
SKIP=${SKIP:-}

skip() { [[ " $SKIP " == *" $1 "* ]]; }

echo "== host: $(hostname)  date: $(date)"
nvidia-smi --query-gpu=name,clocks.max.sm,memory.total --format=csv || echo "(no nvidia-smi)"

make all

# 1. Naive C triple loop (single thread, pinned to one core)
if ! skip naive; then
    echo "== [1/5] CPU naive"
    ./cpu_matmul --check
    taskset -c 0 ./cpu_matmul -o result_cpu_naive.csv
fi

# 2. Optimized C (packing + NEON + OpenMP), one thread per core
if ! skip opt; then
    echo "== [2/5] CPU optimized"
    ./cpu_matmul_opt --check
    OMP_NUM_THREADS=72 OMP_PROC_BIND=close OMP_PLACES=cores ./cpu_matmul_opt -o result_cpu_opt.csv
fi

# 3. numpy (OpenBLAS). This OpenBLAS build has MAX_THREADS=64.
if ! skip numpy; then
    echo "== [3/5] numpy"
    OPENBLAS_NUM_THREADS=64 python bench_numpy.py -o result_numpy.csv
fi

# 4, 5. PyTorch on CUDA, strict FP32 and TF32
if ! skip cuda; then
    echo "== [4/5] PyTorch CUDA FP32"
    python bench_torch.py -o result_cuda_fp32.csv
fi
if ! skip tf32; then
    echo "== [5/5] PyTorch CUDA TF32"
    python bench_torch.py --tf32 -o result_cuda_tf32.csv
fi

echo "== plot"
python plot.py
