"""Benchmark FP32 matmul with numpy (OpenBLAS backend).

Set the thread count with OPENBLAS_NUM_THREADS / OMP_NUM_THREADS.
"""
import argparse
import time

import numpy as np

from sweep import sweep


def bench(n):
    rng = np.random.default_rng(0)
    a = rng.random((n, n), dtype=np.float32)
    b = rng.random((n, n), dtype=np.float32)
    c = np.empty((n, n), dtype=np.float32)
    np.matmul(a, b, out=c)  # warmup
    best, total, reps = float("inf"), 0.0, 0
    while reps < 3 or (total < 1.0 and reps < 1000):
        t0 = time.perf_counter()
        np.matmul(a, b, out=c)
        t = time.perf_counter() - t0
        best = min(best, t)
        total += t
        reps += 1
    return best


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("-o", default="result_numpy.csv")
    p.add_argument("-m", "--max-n", type=int, default=32768)
    args = p.parse_args()
    np.show_config()
    sweep("numpy", bench, args.o, args.max_n)
